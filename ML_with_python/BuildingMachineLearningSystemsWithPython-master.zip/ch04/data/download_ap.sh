#!/bin/sh
wget http://www.cs.princeton.edu/~blei/lda-c/ap.tgz
tar xzf ap.tgz
