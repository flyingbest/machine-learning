Chapter 3 - Clustering - Finding Related Posts
==============================================

For this chapter you will need the '20news' dataset from
http://mlcomp.org/datasets/379. To get the data you will need to
register, but it is totally free. When being logged in, you will 
see a ZIP download link.
