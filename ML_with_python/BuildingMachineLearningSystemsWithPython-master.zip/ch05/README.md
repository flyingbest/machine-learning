Chapter 5 - Classification - Detecting Poor Answers
===================================================

The book chapter is based on StackExchange's data blob from August 2012 for the first edition. 

After publishing the book, StackExchange released the May 2014 version at
[https://archive.org/download/stackexchange/stackexchange_archive.torrent](https://archive.org/download/stackexchange/stackexchange_archive.torrent).

Note that using the latest version, you will get slightly different results.

The code is using pyenchant for spell correction. Pyenchent is only used to increase your pleasure of eperimenting with additional features. It is not used later on the chapter. So, if you find out that your platform poses too big problems to install it (e.g. on 64bit Windows), don't bother.
