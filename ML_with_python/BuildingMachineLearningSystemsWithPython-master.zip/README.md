Building Machine Learning Systems with Python
=============================================

Source Code for the book Building Machine Learning Systems with Python by [Luis
Pedro Coelho](http://luispedro.org) and [Willi Richert](http://twotoreal.com).

The book was published in 2013 (second edition in 2015) by Packt Publishing and
is available [from their
website](http://www.packtpub.com/building-machine-learning-systems-with-python/book).

The code in the repository corresponds to the second edition. Code for the
first edition is available in [first\_edition
branch](https://github.com/luispedro/BuildingMachineLearningSystemsWithPython/tree/first_edition).

