#!/usr/bin/env bash

jug execute image-classification.py
