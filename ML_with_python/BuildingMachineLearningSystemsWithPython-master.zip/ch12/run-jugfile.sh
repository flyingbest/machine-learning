#!/usr/bin/env bash

jug execute

