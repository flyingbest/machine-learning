#-*- coding: utf-8 -*-

#!/usr/bin/env sh
wget http://fimi.ua.ac.be/data/retail.dat.gz
