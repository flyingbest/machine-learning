#!/usr/bin/env bash
curl -L -O http://files.grouplens.org/papers/ml-100k.zip
unzip ml-100k.zip
curl -L -O http://fimi.ua.ac.be/data/retail.dat.gz
